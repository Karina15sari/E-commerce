<?php
// Minimal footer - tidak output apapun
// Semua halaman akan menggunakan struktur HTML lengkap sendiri
?>