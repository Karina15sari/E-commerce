<?php
// Tampilkan semua error untuk debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

$host = 'localhost';
$dbname = 'taniasli';
$username = 'root';
$password = '';

try {
    $dsn = "mysql:host=$host;dbname=$dbname;charset=utf8mb4";
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    
    // Test koneksi
    $pdo->query("SELECT 1");
    
} catch(PDOException $e) {
    // Tampilkan error detail
    echo "<!DOCTYPE html>";
    echo "<html><body>";
    echo "<div style='background: red; color: white; padding: 20px; margin: 20px;'>";
    echo "<h2>Database Connection Error</h2>";
    echo "<p>Error: " . $e->getMessage() . "</p>";
    echo "<p>Please check:</p>";
    echo "<ul>";
    echo "<li>MySQL service is running</li>";
    echo "<li>Database 'taniasli' exists</li>";
    echo "<li>Username and password are correct</li>";
    echo "</ul>";
    echo "</div>";
    echo "</body></html>";
    exit();
}

// Start session only if not started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
